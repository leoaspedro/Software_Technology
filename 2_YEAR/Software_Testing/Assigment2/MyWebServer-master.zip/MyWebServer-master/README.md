MyWebServer
===========

A Simple to use java - webserver


Compile and run
===========
This is one way of compiling it in Linux

run
```find . -name "*.java" | xargs javac -d ../bin```
in the src folder

then move to the bin folder and you can run the application like this:

```java se.lnu.http.HTTPServerConsole 9000 ~/Downloads/MyWebServer-master/bin/se/lnu/http/resources/inner/```

The directory is in my downloads folder and directs it to a folder with a html...
